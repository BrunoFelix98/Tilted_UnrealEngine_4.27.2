#include <iostream>
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <thread>
#include <list>
#include <vector>
#include <string>

#define MAXPENDINGCONNECTIONS 10
#define MAXRECVBUFFER 1024

using namespace std;

struct SessionData {
    int id;
    string name;
    string serverip;
    int serverport;
    string levelID;
};

struct PlayerData {
    int id;
    SOCKET client;
};

list<SessionData> sessions;
list<PlayerData> players;
int sessioncount = 0;
int playercount = 0;

/*  ===== CLIENT MESSAGES TO SERVER =======
* GET LIST OF SESSIONS: g|#
* CREATE NEW SESSION: c|SESSION_NAME|#
* JOIN SESSION: j|SESSION_ID|#
* */

/*  ===== SERVER MESSAGES TO CLIENTS =======
* LIST OF SESSIONS: s|SESSION_ID_1|SESSION_NAME_1|SESSION_ID_2|SESSION_NAME_2| ... #
* CREATE/JOIN CONFIRMATION: o|SESSION_IP|SESSION_PORT|#
* */

void InterpretMessage(char* buffer, PlayerData player)
{
    string temp = "";
    vector<string> parameters;
    char cmd = -1;
    for (int i = 0; buffer[i] != '#'; i++)
    {
        if ((buffer[i] == '|') && (cmd == -1))
        {
            cmd = temp[0];
            temp = "";
        }
        else if (buffer[i] == '|')
        {
            parameters.push_back(temp);
            temp = "";
        }
        else
        {
            temp += buffer[i];
        }
    }
    if (cmd == 'g')
    {
        //s|SESSION_ID_1|SESSION_NAME_1|SESSION_ID_2|SESSION_NAME_2| ... #
        string message = "s|";
        if (sessions.size() > 0)
        { 
            for (list<SessionData>::iterator it = sessions.begin(); it != sessions.end(); it++)
            {
                message += to_string(it->id) + "|" + it->name + "|";
            }
            //message += "#"; //may not be necessary
        }
        else
        {
            //s|null|#
            message += "null|";
            //message += "#"; //may not be necessary
        }
        cout << "Message sent to client: " << message << endl;
        if (send(player.client, message.c_str(), message.length(), 0) == SOCKET_ERROR) 
        {
            cout << "send failed!" << endl;
        }
    }
    else if (cmd == 'c')
    {
        cout << "Session creation" << endl;
        //c|SESSION_NAME|#
        SessionData session;
        session.id = sessioncount++;
        session.levelID = parameters.at(0);
        session.name = session.levelID + " Session ";
        session.serverip = "127.0.0.1"; //INSERT HERE THE IP OF THE DEDICATED GAME SERVER
        session.serverport = 7777; //PORT WHERE THE DEDICATED GAME SERVER IS RUNNING

        //EXECUTE DEDICATED GAME SERVER
        //Example: system("C:\\MYGAME\\DEDICATEDSERVER.EXE");

        sessions.push_back(session);
        //o|SESSION_IP|SESSION_PORT|LEVELID|#
        string message = "o|" + session.serverip + "|" + to_string(session.serverport) + "|" + session.levelID + "|";
        //message += "#"; //may not be necessary
        cout << "Message sent to client: " << message << endl;
        if (send(player.client, message.c_str(), message.length(), 0) == SOCKET_ERROR)
        {
            cout << "send failed!" << endl;
        }
    }
    else if (cmd == 'j')
    {
        //j|SESSION_ID|#
        bool joined = false;
        int sessionID = stoi(parameters.at(0));
        for (list<SessionData>::iterator it = sessions.begin(); it != sessions.end(); it++)
        {
            if (it->id == sessionID)
            {
                //o|SESSION_IP|SESSION_PORT|#
                string message = "o|" + it->serverip + "|" + to_string(it->serverport) + "|";
                cout << "Message sent to client: " << message << endl;
                if (send(player.client, message.c_str(), message.length(), 0) == SOCKET_ERROR)
                {
                    cout << "send failed!" << endl;
                }
                joined = true;
                break;
            }
        }
        if (!joined)
        {
            cout << "join failed!" << endl;
        }
    }
}

void HandleClientConnection(PlayerData player)
{
    char buffer[MAXRECVBUFFER];
    while (recv(player.client, buffer, MAXRECVBUFFER, 0) > 0)
    {
        InterpretMessage(buffer, player);
    }    
    cout << "Player " << player.id << " disconnected!" << endl;
    if (closesocket(player.client) == SOCKET_ERROR)
    {
        cout << "closesocket failed!" << endl;
    }
}

int main()
{
    SOCKET server;
    SOCKADDR_IN serverAddr;
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 0), &wsaData) != NO_ERROR)
    {
        cout << "WSAStartup failed!" << endl;
        return 1;
    }
    server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (server == SOCKET_ERROR)
    {
        cout << "socket failed!" << endl;
        return 2;
    }

    serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(3434);

    if (bind(server, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR)
    {
        cout << "bind failed!" << endl;
        return 3;
    }

    if (listen(server, MAXPENDINGCONNECTIONS) == SOCKET_ERROR)
    {
        cout << "listen failed!" << endl;
        return 4;
    }
    cout << "Server Started!" << endl;

    /*SessionData s1;
    s1.id = 1;
    s1.name = "My Session 1";
    s1.serverip = "127.0.0.1";
    s1.serverport = 7777;
    sessions.push_back(s1);

    SessionData s2;
    s2.id = 2;
    s2.name = "Test session";
    s2.serverip = "127.0.0.1";
    s2.serverport = 7777;
    sessions.push_back(s2);*/

    while (true)
    {
        SOCKET client;
        SOCKADDR_IN clientAddr;
        int clientLength = sizeof(clientAddr);
        client = accept(server, (struct sockaddr*)&clientAddr, &clientLength);
        if (client == INVALID_SOCKET)
        {
            cout << "accept failed!" << endl;
        }
        else
        {
            char ip[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, &(clientAddr.sin_addr), ip, INET_ADDRSTRLEN);
            cout << "Client " << ip << " connected!" << endl;
            PlayerData player;
            player.client = client;
            player.id = playercount++;
            players.push_back(player);
            thread* clientThread = new thread(HandleClientConnection, player);
        }
    }
    WSACleanup();
    return 0;
}